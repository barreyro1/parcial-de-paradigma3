<?php
session_start();
include '../db/lb_db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $lb_email = $_POST['lb_email'];
    $lb_password = $_POST['lb_password'];

    $sql = "SELECT * FROM lb_usuarios WHERE email='$lb_email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($lb_password, $row['password'])) {
            $_SESSION['loggedin'] = true;
            $_SESSION['username'] = $row['nombre'];
            $_SESSION['role'] = $row['rol'];
            $_SESSION['user_id'] = $row['id']; // Almacena el user_id en la sesión
            header("Location: /parcial/index.php");
            exit();
        } else {
            echo "Contraseña incorrecta";
        }
    } else {
        echo "No existe una cuenta con ese email";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="../lb_styles.css">
    <script src="../js/lb_validations.js"></script>
</head>
<body>
    <div class="lb_form-container">
        <h2>Login</h2>
        <form id="lb_loginForm" method="POST" action="lb_login.php" onsubmit="return lb_validateLogin()">
            <label for="lb_email">Email:</label>
            <input type="email" id="lb_email" name="lb_email" required>
            <label for="lb_password">Contraseña:</label>
            <input type="password" id="lb_password" name="lb_password" required>
            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>