<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta - Aerolínea XYZ</title>
    <link rel="stylesheet" href="../css/styles.css">
    <script src="../js/scripts.js" defer></script>
</head>
<body>
    <header class="header">
        <nav class="nav">
            <ul class="nav-list">
                <li class="nav-item"><a href="../index.php" class="nav-link">Inicio</a></li>
                <li class="nav-item"><a href="alta.php" class="nav-link">Alta</a></li>
                <li class="nav-item"><a href="baja.php" class="nav-link">Baja</a></li>
                <li class="nav-item"><a href="modificacion.php" class="nav-link">Modificación</a></li>
                <li class="nav-item"><a href="consulta.php" class="nav-link">Consulta</a></li>
            </ul>
        </nav>
    </header>

    <main class="main-content">
        <h2>Consulta de Paquetes</h2>
        <div id="consulta-paquetes"></div>
    </main>

    <footer class="footer">
        <p class="footer-text">&copy; 2023 Aerolínea XYZ. Todos los derechos reservados.</p>
    </footer>
</body>
</html>