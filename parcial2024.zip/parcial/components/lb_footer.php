<footer class="lb_footer">
    <p>&copy; 2023 Agencia Inmobiliaria. Todos los derechos reservados.</p>
</footer>