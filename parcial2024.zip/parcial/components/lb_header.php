<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>

<header class="lb_header">
    <div class="lb_logo">
        <h1>Agencia Inmobiliaria</h1>
    </div>
    <nav class="lb_nav">
        <a href="/parcial/index.php">Inicio</a>
        <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true): ?>
            <a href="/parcial/pages/lb_list_properties.php">Propiedades</a>
            <?php if ($_SESSION['role'] === 'admin'): ?>
                <a href="/parcial/pages/lb_add_property.php">Añadir Inmueble</a>
                <a href="/parcial/pages/lb_list_contacts.php">Listado de Contactos</a>
            <?php endif; ?>
            <a href="/parcial/pages/lb_logout.php">Cerrar Sesión</a>
        <?php else: ?>
            <a href="/parcial/pages/lb_contact.php">Contacto</a>
            <a href="/parcial/pages/lb_login.php">Iniciar Sesión</a>
            <a href="/parcial/pages/lb_register.php">Registro</a>
        <?php endif; ?>
    </nav>
</header>