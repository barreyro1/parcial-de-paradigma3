<?php
include '../db/lb_db.php';

$sql = "SELECT * FROM lb_propiedades";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Propiedades</title>
    <link rel="stylesheet" href="../lb_styles.css">
</head>
<body>
    <?php include '../components/lb_header.php'; ?>

    <div class="lb_container">
        <h2>Lista de Propiedades</h2>
        <?php if ($result->num_rows > 0): ?>
            <div class="lb_properties-grid">
                <?php while($row = $result->fetch_assoc()): ?>
                    <div class="lb_property-card">
                        <h3><?php echo $row['titulo']; ?></h3>
                        <p><?php echo $row['descripcion']; ?></p>
                        <p><strong>Precio:</strong> $<?php echo $row['precio']; ?></p>
                        <p><strong>Dirección:</strong> <?php echo $row['direccion']; ?></p>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <p>No hay propiedades disponibles.</p>
        <?php endif; ?>
    </div>

    <?php include '../components/lb_footer.php'; ?>
</body>
</html>

<?php
$conn->close();
?>