function lb_validateRegister() {
    var lb_name = document.getElementById('lb_name').value;
    var lb_email = document.getElementById('lb_email').value;
    var lb_password = document.getElementById('lb_password').value;

    if (lb_name === "" || lb_email === "" || lb_password === "") {
        alert("All fields are required");
        return false;
    }

    if (lb_password.length < 6) {
        alert("Password must be at least 6 characters long");
        return false;
    }

    return true;
}

function lb_validateLogin() {
    var lb_email = document.getElementById('lb_email').value;
    var lb_password = document.getElementById('lb_password').value;

    if (lb_email === "" || lb_password === "") {
        alert("All fields are required");
        return false;
    }

    return true;
}