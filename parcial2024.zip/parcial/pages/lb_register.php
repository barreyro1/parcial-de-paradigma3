<?php
include '../db/lb_db.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $lb_name = $_POST['lb_name'];
    $lb_email = $_POST['lb_email'];
    $lb_password = password_hash($_POST['lb_password'], PASSWORD_DEFAULT);
    $lb_role = 'user';

    $sql = "INSERT INTO lb_usuarios (nombre, email, password, rol) VALUES ('$lb_name', '$lb_email', '$lb_password', '$lb_role')";

    if ($conn->query($sql) === TRUE) {
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $lb_name;
        $_SESSION['role'] = $lb_role;
        $_SESSION['user_id'] = $conn->insert_id;

        header("Location: /parcial/index.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link rel="stylesheet" href="../lb_styles.css">
    <script src="../js/lb_validations.js"></script>
</head>
<body>
    <div class="lb_form-container">
        <h2>Registro</h2>
        <form id="lb_registerForm" method="POST" action="lb_register.php" onsubmit="return lb_validateRegister()">
            <label for="lb_name">Nombre:</label>
            <input type="text" id="lb_name" name="lb_name" required>
            <label for="lb_email">Email:</label>
            <input type="email" id="lb_email" name="lb_email" required>
            <label for="lb_password">Contraseña:</label>
            <input type="password" id="lb_password" name="lb_password" required>
            <button type="submit">Registrar</button>
        </form>
    </div>
</body>
</html>