-- Comprobar si la base de datos ya existe y crearla si no existe
CREATE DATABASE IF NOT EXISTS lb_inmobiliaria;

-- Usar la base de datos
USE lb_inmobiliaria;

-- Comprobar si la tabla lb_usuarios ya existe y crearla si no existe
CREATE TABLE IF NOT EXISTS lb_usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    rol ENUM('admin', 'user') DEFAULT 'user',
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Comprobar si la tabla lb_propiedades ya existe y crearla si no existe
CREATE TABLE IF NOT EXISTS lb_propiedades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100) NOT NULL,
    descripcion TEXT NOT NULL,
    precio DECIMAL(10, 2) NOT NULL,
    direccion VARCHAR(255) NOT NULL,
    fecha_publicacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    usuario_id INT,
    FOREIGN KEY (usuario_id) REFERENCES lb_usuarios(id)
);

-- Comprobar si la tabla lb_contactos ya existe y crearla si no existe
CREATE TABLE IF NOT EXISTS lb_contactos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL,
    mensaje TEXT NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
