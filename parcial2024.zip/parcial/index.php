<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agencia Inmobiliaria</title>
    <link rel="stylesheet" href="lb_styles.css">
</head>
<body>
    <?php include 'components/lb_header.php'; ?>

    <!-- Hero Section -->
    <section class="lb_section lb_hero" id="home">
        <div class="lb_hero-content">
            <h1>Bienvenidos a Nuestra Agencia Inmobiliaria</h1>
            <p>Encuentra la casa de tus sueños con nosotros.</p>
        </div>
    </section>

    <!-- Qué Hacemos Section -->
    <section class="lb_section" id="services">
        <h2>Qué Hacemos</h2>
        <p>Nos especializamos en la venta de inmuebles. Ofrecemos una amplia variedad de propiedades para que encuentres la que mejor se adapte a tus necesidades.</p>
    </section>

    <!-- Contacto Section -->
    <section class="lb_section" id="contact">
        <h2>Contacto</h2>
        <p>Ponte en contacto con nosotros para más información.</p>
        <a href="/parcial/pages/lb_contact.php" class="lb_button">Contáctanos</a>
    </section>

    <?php include 'components/lb_footer.php'; ?>
</body>
</html>