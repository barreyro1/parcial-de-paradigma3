document.addEventListener('DOMContentLoaded', function() {
    // Llamada asincrónica para obtener paquetes de viajes
    if (document.getElementById('consulta-paquetes')) {
        fetch('/api/get_paquetes.php')
            .then(response => response.json())
            .then(data => {
                const paquetesContainer = document.getElementById('consulta-paquetes');
                data.forEach(paquete => {
                    const paqueteElement = document.createElement('div');
                    paqueteElement.classList.add('paquete');
                    paqueteElement.innerHTML = `
                        <h3>${paquete.Nombre}</h3>
                        <p>Descripción: ${paquete.Descripcion}</p>
                        <p>Precio: ${paquete.Precio}</p>
                    `;
                    paquetesContainer.appendChild(paqueteElement);
                });
            })
            .catch(error => console.error('Error:', error));
    }
});