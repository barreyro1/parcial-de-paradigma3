<?php
include '../db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];

    $sql = "DELETE FROM Paquete WHERE IdPaquete = $id";
    if ($conn->query($sql) === TRUE) {
        echo "Paquete eliminado exitosamente";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Baja - Aerolínea XYZ</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <header class="header">
        <nav class="nav">
            <ul class="nav-list">
                <li class="nav-item"><a href="../index.php" class="nav-link">Inicio</a></li>
                <li class="nav-item"><a href="alta.php" class="nav-link">Alta</a></li>
                <li class="nav-item"><a href="baja.php" class="nav-link">Baja</a></li>
                <li class="nav-item"><a href="modificacion.php" class="nav-link">Modificación</a></li>
                <li class="nav-item"><a href="consulta.php" class="nav-link">Consulta</a></li>
            </ul>
        </nav>
    </header>

    <main class="main-content">
        <h2>Baja de Paquete</h2>
        <form action="baja.php" method="post">
            <label for="id">ID del Paquete:</label>
            <input type="number" id="id" name="id" required>
            <input type="submit" value="Eliminar">
        </form>
    </main>

    <footer class="footer">
        <p class="footer-text">&copy; 2023 Aerolínea XYZ. Todos los derechos reservados.</p>
    </footer>
</body>
</html>