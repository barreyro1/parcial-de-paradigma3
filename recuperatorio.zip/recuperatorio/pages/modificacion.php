<?php
include '../db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $idViaje = $_POST['idViaje'];
    $idHotel = $_POST['idHotel'];
    $idComida = $_POST['idComida'];
    $idTransporte = $_POST['idTransporte'];
    $precio = $_POST['precio'];
    $numPlazas = $_POST['numPlazas'];

    $sql = "UPDATE Paquete SET IdViaje='$idViaje', IdHotel='$idHotel', IdComida='$idComida', IdTransporte='$idTransporte', Precio='$precio', NumPlazas='$numPlazas' WHERE IdPaquete=$id";
    if ($conn->query($sql) === TRUE) {
        echo "Paquete modificado exitosamente";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificación - Aerolínea XYZ</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <header class="header">
        <nav class="nav">
            <ul class="nav-list">
                <li class="nav-item"><a href="../index.php" class="nav-link">Inicio</a></li>
                <li class="nav-item"><a href="alta.php" class="nav-link">Alta</a></li>
                <li class="nav-item"><a href="baja.php" class="nav-link">Baja</a></li>
                <li class="nav-item"><a href="modificacion.php" class="nav-link">Modificación</a></li>
                <li class="nav-item"><a href="consulta.php" class="nav-link">Consulta</a></li>
            </ul>
        </nav>
    </header>

    <main class="main-content">
        <h2>Modificación de Paquete</h2>
        <form action="modificacion.php" method="post">
            <label for="id">ID del Paquete:</label>
            <input type="number" id="id" name="id" required>
            <label for="idViaje">ID del Viaje:</label>
            <input type="number" id="idViaje" name="idViaje" required>
            <label for="idHotel">ID del Hotel:</label>
            <input type="number" id="idHotel" name="idHotel" required>
            <label for="idComida">ID de la Comida:</label>
            <input type="number" id="idComida" name="idComida" required>
            <label for="idTransporte">ID del Transporte:</label>
            <input type="number" id="idTransporte" name="idTransporte" required>
            <label for="precio">Precio:</label>
            <input type="number" id="precio" name="precio" step="0.01" required>
            <label for="numPlazas">Número de Plazas:</label>
            <input type="number" id="numPlazas" name="numPlazas" required>
            <input type="submit" value="Modificar">
        </form>
    </main>

    <footer class="footer">
        <p class="footer-text">&copy; 2023 Aerolínea XYZ. Todos los derechos reservados.</p>
    </footer>
</body>
</html>