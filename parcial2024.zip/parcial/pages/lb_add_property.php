<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header("Location: /parcial/index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Añadir Inmueble</title>
    <link rel="stylesheet" href="../lb_styles.css">
</head>
<body>
    <?php include '../components/lb_header.php'; ?>
    <div class="lb_form-container">
        <h2>Añadir Inmueble</h2>
        <form method="POST" action="lb_add_property.php">
            <label for="lb_title">Título:</label>
            <input type="text" id="lb_title" name="lb_title" required>
            <label for="lb_description">Descripción:</label>
            <textarea id="lb_description" name="lb_description" required></textarea>
            <label for="lb_price">Precio:</label>
            <input type="number" id="lb_price" name="lb_price" required>
            <label for="lb_address">Dirección:</label>
            <input type="text" id="lb_address" name="lb_address" required>
            <button type="submit">Añadir</button>
        </form>
    </div>
    <?php include '../components/lb_footer.php'; ?>
</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include '../db/lb_db.php';

    $lb_title = $_POST['lb_title'];
    $lb_description = $_POST['lb_description'];
    $lb_price = $_POST['lb_price'];
    $lb_address = $_POST['lb_address'];
    $lb_user_id = $_SESSION['user_id'];

    $sql = "INSERT INTO lb_propiedades (titulo, descripcion, precio, direccion, usuario_id) VALUES ('$lb_title', '$lb_description', '$lb_price', '$lb_address', '$lb_user_id')";

    if ($conn->query($sql) === TRUE) {
        echo "Inmueble añadido exitosamente";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>