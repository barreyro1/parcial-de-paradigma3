<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header("Location: /parcial/index.php");
    exit();
}

include '../db/lb_db.php';

$sql = "SELECT * FROM lb_contactos";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Contactos</title>
    <link rel="stylesheet" href="../lb_styles.css">
</head>
<body>
    <?php include '../components/lb_header.php'; ?>
    <div class="lb_container">
        <h2>Lista de Contactos</h2>
        <?php if ($result->num_rows > 0): ?>
            <table class="lb_table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Email</th>
                        <th>Mensaje</th>
                        <th>Fecha</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['nombre']; ?></td>
                            <td><?php echo $row['email']; ?></td>
                            <td><?php echo $row['mensaje']; ?></td>
                            <td><?php echo $row['fecha']; ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay contactos disponibles.</p>
        <?php endif; ?>
    </div>
    <?php include '../components/lb_footer.php'; ?>
</body>
</html>

<?php
$conn->close();
?>