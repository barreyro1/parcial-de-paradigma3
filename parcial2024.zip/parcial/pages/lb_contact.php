<?php
    include '../db/lb_db.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $lb_name = $_POST['lb_name'];
        $lb_email = $_POST['lb_email'];
        $lb_message = $_POST['lb_message'];

        $sql = "INSERT INTO lb_contactos (nombre, email, mensaje) VALUES ('$lb_name', '$lb_email', '$lb_message')";

        if ($conn->query($sql) === TRUE) {
            echo "Mensaje enviado exitosamente";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacto</title>
    <link rel="stylesheet" href="../lb_styles.css">
</head>
<body>
    <?php include '../components/lb_header.php'; ?>
    <div class="lb_form-container">
        <h2>Contacto</h2>
        <form method="POST" action="lb_contact.php">
            <label for="lb_name">Nombre:</label>
            <input type="text" id="lb_name" name="lb_name" required>
            <label for="lb_email">Email:</label>
            <input type="email" id="lb_email" name="lb_email" required>
            <label for="lb_message">Mensaje:</label>
            <textarea id="lb_message" name="lb_message" required></textarea>
            <button type="submit">Enviar</button>
        </form>
    </div>
    <?php include '../components/lb_footer.php'; ?>
</body>
</html>