<footer class="footer">
        <p class="footer-text">&copy; 2023 Aerolínea XYZ. Todos los derechos reservados.</p>
    </footer>
</body>
</html>